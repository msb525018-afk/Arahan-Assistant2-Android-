# Arahan Assistant: no custom shrinker rules required.
