# Arahan Assistant — پروژه آماده ساخت Android

این پروژه از رابط وب فعلی Arahan Assistant به‌صورت آفلاین داخل WebView اندروید استفاده می‌کند. فایل‌های رابط در `app/src/main/assets/public` قرار دارند؛ هیچ APK جعلی یا فایل تغییرنام‌یافته‌ای در این بسته وجود ندارد.

## ساخت APK در Android Studio
1. این پوشه را در Android Studio باز کنید.
2. اجازه دهید Gradle Sync کامل شود.
3. از منوی **Build > Build APK(s)** استفاده کنید.
4. خروجی در مسیر `app/build/outputs/apk/debug/app-debug.apk` قرار می‌گیرد.

برای نسخه انتشار، از **Build > Generate Signed App Bundle / APK** استفاده کنید و یک keystore واقعی انتخاب کنید.

شناسه برنامه: `com.arahan.assistant`  
نام برنامه: `Arahan Assistant`  
نسخه: `1.0.0`  
حداقل Android: API 23  
هدف: API 35
